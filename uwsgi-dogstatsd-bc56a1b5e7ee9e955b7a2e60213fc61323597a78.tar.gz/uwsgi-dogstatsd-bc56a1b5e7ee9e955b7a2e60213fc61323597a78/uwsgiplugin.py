NAME = 'dogstatsd'

CFLAGS = []
LDFLAGS = []
LIBS = []

GCC_LIST = ['plugin']
