from snuba.utils.streams.backends.local.storages.abstract import MessageStorage

__all__ = [
    "MessageStorage",
]
