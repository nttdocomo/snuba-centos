from typing import Mapping

Tags = Mapping[str, str]
