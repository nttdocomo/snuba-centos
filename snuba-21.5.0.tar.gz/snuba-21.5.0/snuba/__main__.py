if __name__ == "__main__":
    from snuba.cli import main

    main()
