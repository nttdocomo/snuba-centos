Snuba is a service that provides a rich data model on top of Clickhouse together
with a fast ingestion consumer and a query optimizer.


.. toctree::
   :maxdepth: 1
   :caption: Contents:

   architecture/overview
   architecture/datamodel
   architecture/queryprocessing
   language/snql
