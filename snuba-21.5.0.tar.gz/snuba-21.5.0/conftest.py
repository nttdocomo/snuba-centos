import os

os.environ.setdefault("SNUBA_SETTINGS", "test")
os.environ.setdefault("CLICKHOUSE_DATABASE", "snuba_test")
